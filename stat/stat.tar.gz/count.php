<?php
// Вывод изображения
Header("Content-type: image/gif");
$im = imagecreate(1,1);
$background_color = imagecolorallocate($im, 0, 0, 0);
$cbg = imagecolorclosest($im, 0, 0, 0);
//$im = imagecreatefromgif("defstat.gif");
//$cbg = imagecolorclosest($im, 252, 1, 155);
imagecolortransparent($im, $cbg);

require_once "../system/conf_mysql.php";

if (!mysql_connect(HostName, DBUserName, DBPassword)) {
    ImageGif($im);
    ImageDestroy($im);
	    return;
}else mysql_select_db(DBName);

if (isset($_COOKIE['statidus'])) {
//  imagettftext ($im, 20, 0, 10, 10, imagecolorallocate($im, 0, 0, 0), "arial.ttf", "!!!");

    $iduser = intval($_COOKIE['statidus']);
    $query = $_SERVER['QUERY_STRING'];
    parse_str($query);
    //echo $iduser."<br>".$width."X".$height."<br>".$pix."<br>".$java."<br>".$js."<br>".$timestart."<br>".$idlog."<br>";

    // --- Определяем скорось загрузки страницы ---
    list($usec, $sec) = explode(" ", microtime());
    $timestop = ((float)$usec + (float)$sec);
    if (!empty($timestart)) $page_rateload = floatval($timestop - $timestart);
    else $page_rateload = 0;

    // --- Обновляем запись в таблице посетителей ---
    mysql_query("
    UPDATE stat_users
    SET screensize = '".$width."x".$height."',
        colorsdepth = '".$pix."',
        java = '".$java."',
        javascript = '".$js."'
    WHERE id = '".$iduser."'");

    mysql_query("
    UPDATE stat_log
    SET page_rateload = '".$page_rateload."'
    WHERE id = '".$idlog."'");

    //imagettftext($im, 5, 0, 5, 28, imagecolorallocate($im, 0, 0, 0), "arial.ttf", $idlog);

}

ImageGif($im);
ImageDestroy($im);
?>