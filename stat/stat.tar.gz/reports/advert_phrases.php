<?php

/// *** Выводим таблицу *** ///
$html .= "<center><br><table class='tblval_report' border=0 width=100%>
    <tr class='tbltitle'><td align=left colspan=2><b>ОТЧЕТ НАХОДИТСЯ В РАЗРАБОТКЕ</b></td></tr></table></center>";

print $html;
$NOFILTER = 1;
?>